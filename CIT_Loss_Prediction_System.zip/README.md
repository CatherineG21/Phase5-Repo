# CIT Loss Prediction System

## Quick Start

### For Anaconda Users (Recommended):
1. Open **Anaconda Prompt**
2. Navigate to this folder: `cd path/to/CIT_Final_Package`
3. Run: `python app.py`
4. Open browser to: http://localhost:5000

### For Regular Python Users:
1. Open Command Prompt/Terminal in this folder
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open browser to: http://localhost:5000

## Features
- **CIT Batch Processing**: Upload multiple CIT returns (CSV/Excel)
- **Risk Calculator**: Individual taxpayer risk assessment
- **Raw Input**: Direct CIT data entry
- **Audit Management**: View and manage audit cases

## System Requirements
- Python 3.7 or higher
- 500MB free disk space
- Web browser (Chrome, Firefox, Edge)

## Note for Anaconda Users
Running from Anaconda Prompt ensures your existing Jupyter/IPython
installation remains unaffected.

## Troubleshooting
If you see "Module not found" errors:
- Run: `pip install -r requirements.txt`
- Or use Anaconda Prompt

If browser doesn't connect:
- Make sure you see "Running on http://localhost:5000"
- Don't close the terminal window while using the system
